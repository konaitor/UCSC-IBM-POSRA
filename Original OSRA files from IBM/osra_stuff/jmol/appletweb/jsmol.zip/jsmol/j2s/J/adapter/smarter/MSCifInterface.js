Clazz.declarePackage ("J.adapter.smarter");
Clazz.load (["J.adapter.smarter.MSInterface"], "J.adapter.smarter.MSCifInterface", null, function () {
Clazz.declareInterface (J.adapter.smarter, "MSCifInterface", J.adapter.smarter.MSInterface);
});

Clazz.declarePackage ("J.api");
Clazz.load (["J.api.MOCalculationInterface"], "J.api.QuantumPlaneCalculationInterface", null, function () {
Clazz.declareInterface (J.api, "QuantumPlaneCalculationInterface", J.api.MOCalculationInterface);
});

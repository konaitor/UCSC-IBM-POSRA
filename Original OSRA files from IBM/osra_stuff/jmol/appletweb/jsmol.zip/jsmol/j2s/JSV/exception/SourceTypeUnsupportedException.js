Clazz.declarePackage ("JSV.exception");
Clazz.load (["JSV.exception.JSpecViewException"], "JSV.exception.SourceTypeUnsupportedException", null, function () {
c$ = Clazz.declareType (JSV.exception, "SourceTypeUnsupportedException", JSV.exception.JSpecViewException);
});

Clazz.declarePackage ("JSV.exception");
Clazz.load (["java.lang.Exception"], "JSV.exception.JSpecViewException", null, function () {
c$ = Clazz.declareType (JSV.exception, "JSpecViewException", Exception);
});

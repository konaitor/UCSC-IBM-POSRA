Clazz.declarePackage ("JSV.exception");
Clazz.load (["JSV.exception.JSpecViewException"], "JSV.exception.SVGException", null, function () {
c$ = Clazz.declareType (JSV.exception, "SVGException", JSV.exception.JSpecViewException);
});
